let num, total, resultado;

num = prompt("Digite um número:");

total = num / 2;

if (num%2 == 0){
    alert(num + " é par.")
}

else{
    alert(num + " é impar.")
}